package com.bank.sim.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bank.sim.R

class MainActivity: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_main)
        // TODO: bind ViewModel, show balance and transactions, simulate MFA
    }
}
